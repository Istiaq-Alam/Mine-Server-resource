# @s = nullscape.rift_gateway marker in gateway block that has exit_portal data
# at @s
# run from nullscape:tick

# store pos
data modify entity @s data.nullscape.exit_portal set from block ~ ~ ~ exit_portal
# set surrounding gateways
execute at @e[type=minecraft:marker,tag=nullscape.rift_gateway,distance=0.5..10] run data modify block ~ ~ ~ exit_portal set from entity @s data.nullscape.exit_portal
# cleanup, should also kill @s
kill @e[type=minecraft:marker,tag=nullscape.rift_gateway,distance=..10]
