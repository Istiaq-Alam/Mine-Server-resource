particle smoke ~ ~0.5 ~ 0.5 0.2 0.5 0.1 50 force @a
playsound block.fire.extinguish voice @a ~ ~ ~ 2 1
kill @e[tag=fire,distance=..5]