execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute at @s[scores={skilltime=..3}] run playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=..3}] run playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=..3}] run playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=..3}] run playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5

scoreboard players add @s s18b 1

execute at @s[scores={s18b=2}] run summon armor_stand ^ ^ ^ {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s18a","fire"]}
scoreboard players reset @s[scores={s18b=2}] s18b
execute at @s[scores={skilltime=1..3}] run tp @s ^ ^ ^0.6
execute at @s[scores={skilltime=4..6}] run tp @s ^ ^ ^1
execute at @s[scores={skilltime=7..9}] run tp @s ^ ^ ^1.4
execute at @s[scores={skilltime=10..}] run tp @s ^ ^ ^1.8

#particle item{item:{id:blue_stained_glass_pane}} ~ ~1 ~ 0.7 0 0.7 0.01 20 force @a
#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
execute positioned ~ ~3 ~ run function tutorial:s18p1
execute positioned ~ ~1.5 ~ run particle flame ~ ~ ~ 0.2 1.5 0.2 0.1 30 force @a
execute positioned ~ ~1.5 ~ run particle lava ~ ~ ~ 0.2 1.5 0.2 0.1 5 force @a

#execute positioned ~ ~1 ~ run function tutorial:att
playsound entity.blaze.burn voice @a ~ ~ ~ 0.5 1
playsound entity.blaze.burn voice @a ~ ~ ~ 0.5 1
playsound entity.blaze.burn voice @a ~ ~ ~ 0.5 1
playsound entity.blaze.shoot voice @a ~ ~ ~ 0.5 0.7
playsound entity.blaze.shoot voice @a ~ ~ ~ 0.5 0.5
playsound entity.blaze.shoot voice @a ~ ~ ~ 0.5 0.5
#fire

execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob18] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s18=1..},limit=1,sort=nearest]


execute unless block ~ ~0.5 ~ air run kill @s
execute at @s as @a[distance=..3,scores={s18=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s18=1..},limit=1,sort=nearest]
#execute at @s[scores={skilltime=..2}] rotated as @p[scores={s18=1..},limit=1,sort=nearest,distance=..3] run tp @s ~ ~ ~ ~ ~



execute if entity @e[type=armor_stand,tag=water,distance=..3] run function tutorial:nowater

kill @s[scores={skilltime=30..}]
