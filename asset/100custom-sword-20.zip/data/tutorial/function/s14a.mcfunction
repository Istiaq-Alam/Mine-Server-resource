execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute at @s[scores={skilltime=1..},tag=!s14s] run tp @s ^ ^ ^1.2

#execute at @s[scores={skilltime=2..10},tag=s14s] run tp @s ^ ^ ^1.2
execute at @s[scores={skilltime=1..},tag=s14s] run tp @s ^ ^ ^2.2


#particle item{item:{id:blue_stained_glass_pane}} ~ ~1 ~ 0.7 0 0.7 0.01 20 force @a
execute at @s[tag=!s14s] run particle sweep_attack ~ ~1 ~ 0.7 0 0.7 1 20 force @a
execute at @s[tag=s14s] run particle sweep_attack ~ ~1 ~ 0.7 0 0.7 5 20 force @a

execute at @s[tag=!s14s] run particle dust{color:[1.0,0.97,0.0],scale:2} ~ ~1 ~ 0.6 0.1 0.6 0 30 force @a
execute at @s[tag=!s14s] run particle end_rod ~ ~1 ~ 0.6 0.1 0.6 0.2 2 force @a


execute at @s[tag=s14s] run particle dust{color:[1.0,0.97,0.0],scale:4} ~ ~1 ~ 1.5 0.2 1.5 0 80 force @a
execute at @s[tag=s14s] run particle end_rod ~ ~1 ~ 1.5 0.1 1.5 0.2 10 force @a
execute at @s[tag=s14s] run particle end_rod ~ ~1 ~ 1.5 0.1 1.5 0.4 10 force @a

#function tutorial:s14p1
#execute positioned ~ ~1 ~ run function tutorial:att
execute at @s[tag=!s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1
execute at @s[tag=s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 2 0.7
execute at @s[tag=!s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1
execute at @s[tag=s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 0.7
execute at @s[tag=!s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1
execute at @s[tag=s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 0.7
execute at @s[tag=!s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1
execute at @s[tag=s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 0.7
execute at @s[tag=!s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1
execute at @s[tag=s14s] run playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 0.7
#fire

execute at @s[tag=!s14s] as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob14] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s14=1..},limit=1,sort=nearest]
execute at @s[tag=s14s] as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob14] at @s run damage @s 40 minecraft:mob_projectile by @e[scores={s14=1..},limit=1,sort=nearest]


execute unless block ~ ~0.5 ~ air run kill @s
execute at @s[tag=!s14s] as @a[distance=..3,scores={s14=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s14=1..},limit=1,sort=nearest]
execute at @s[tag=s14s] as @a[distance=..3,scores={s14=..1},tag=!ff] at @s run damage @s 30 minecraft:mob_projectile by @e[scores={s14=1..},limit=1,sort=nearest]

#execute at @s[scores={skilltime=..2}] rotated as @p[scores={s1=1..},limit=1,sort=nearest,distance=..3] run tp @s ~ ~ ~ ~ ~

execute if entity @e[type=armor_stand,tag=skill,tag=!s14,distance=..4] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=armor_stand,tag=skill,tag=!s14,distance=..4] run particle flash ~ ~ ~ 0 0 0 0 1 force @a

execute if entity @e[type=#impact_projectiles,distance=..4] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=#impact_projectiles,distance=..4] run particle flash ~ ~ ~ 0 0 0 0 1 force @a

kill @e[type=#impact_projectiles,distance=..4]
kill @e[type=armor_stand,tag=skill,tag=!s14,distance=..4]



kill @s[scores={skilltime=15..}]



execute if entity @e[type=armor_stand,tag=skill,tag=!s14,distance=..3] run function tutorial:nowater