execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~-0.3 ~ air run tp @s ~ ~-0.1 ~
execute at @s[scores={skilltime=2..}] if block ~ ~ ~ air run tp @s ^ ^ ^0.4
execute at @s[scores={skilltime=2}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=2}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=2}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=2}] run particle explosion ~ ~ ~ 1.5 0.1 1.5 0.1 20 force @a 
execute at @s[scores={skilltime=2}] run particle explosion ~ ~ ~ 1.5 0.1 1.5 0.1 20 force @a 
execute at @s[scores={skilltime=2}] run particle item{item:{id:stone}} ~ ~ ~ 1.5 0.3 1.5 0.1 300 force @a
execute at @s[scores={skilltime=2}] run scoreboard players add @a[distance=..4,scores={s17=..-20}] fly 10
execute at @s[scores={skilltime=2}] run scoreboard players add @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob17] fly 10
execute at @s[scores={skilltime=2}] as @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob17] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s17=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=2}] as @a[distance=..4,scores={s17=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s17=1..},limit=1,sort=nearest]




#execute at @s[scores={skilltime=12}] run tp @s ^ ^ ^4
execute at @s[scores={skilltime=12}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=12}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=12}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=12}] run particle explosion ~ ~ ~ 1.5 0.1 1.5 0.1 20 force @a 
execute at @s[scores={skilltime=12}] run particle item{item:{id:stone}} ~ ~ ~ 1.5 0.3 1.5 0.1 300 force @a
execute at @s[scores={skilltime=12}] run scoreboard players add @a[distance=..4,scores={s17=..-20}] fly 10
execute at @s[scores={skilltime=12}] run scoreboard players add @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob17] fly 10
execute at @s[scores={skilltime=12}] as @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob17] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s17=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=12}] as @a[distance=..4,scores={s17=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s17=1..},limit=1,sort=nearest]





#execute at @s[scores={skilltime=22}] run tp @s ^ ^ ^4
execute at @s[scores={skilltime=22}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=22}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=22}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 0.7
execute at @s[scores={skilltime=22}] run particle explosion ~ ~ ~ 1.5 0.1 1.5 0.1 20 force @a 
execute at @s[scores={skilltime=22}] run particle item{item:{id:stone}} ~ ~ ~ 1.5 0.3 1.5 0.1 300 force @a
execute at @s[scores={skilltime=22}] run scoreboard players add @a[distance=..4,scores={s17=..-20}] fly 10
execute at @s[scores={skilltime=22}] run scoreboard players add @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob17] fly 10
execute at @s[scores={skilltime=22}] as @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob17] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s17=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=22}] as @a[distance=..4,scores={s17=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s17=1..},limit=1,sort=nearest]

kill @s[scores={skilltime=30..}]

