scoreboard objectives add burst_cooldown dummy
scoreboard objectives add impulse_cooldown dummy
scoreboard objectives add skilltime dummy
scoreboard objectives add mana dummy
scoreboard objectives add skill_cd dummy
scoreboard objectives add Pskill_cd dummy
scoreboard objectives add hit minecraft.custom:minecraft.damage_dealt
scoreboard objectives add fly dummy
scoreboard objectives add mana1 dummy
scoreboard objectives add sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add sneak1 dummy
scoreboard objectives add s0 dummy
scoreboard objectives add s1 dummy
scoreboard objectives add s2 dummy
scoreboard objectives add s3 dummy
scoreboard objectives add s4 dummy
scoreboard objectives add s5 dummy
scoreboard objectives add s10a dummy
scoreboard objectives add manaspeed dummy
scoreboard players set .manaspeed manaspeed 1
scoreboard objectives add jump dummy
scoreboard objectives add jump1 dummy
scoreboard objectives add mob dummy

scoreboard objectives add tp dummy
scoreboard objectives add forward dummy
#scoreboard objectives add summon dummy



scoreboard objectives add target dummy
scoreboard objectives add mobskill dummy
scoreboard objectives add 2 dummy

scoreboard objectives add FF dummy
scoreboard players set .FF FF 1

scoreboard objectives add s5hit dummy
scoreboard players set @a mana 200
scoreboard objectives add s6 dummy
scoreboard objectives add s7 dummy
scoreboard objectives add s8 dummy
scoreboard objectives add s9 dummy
scoreboard objectives add s10 dummy
scoreboard objectives add s11 dummy
scoreboard objectives add s12 dummy
scoreboard objectives add s13 dummy
scoreboard objectives add s14 dummy
scoreboard objectives add s14a dummy
scoreboard objectives add s14b dummy
scoreboard objectives add s14c dummy
scoreboard objectives add st dummy
scoreboard objectives add cd dummy

scoreboard objectives add s15 dummy
scoreboard objectives add s16 dummy
scoreboard objectives add s16a dummy
scoreboard objectives add s17 dummy
scoreboard objectives add s18 dummy
scoreboard objectives add s18b dummy



scoreboard objectives add s19 dummy
scoreboard objectives add s20 dummy
scoreboard objectives add s20a dummy
scoreboard objectives add s20b dummy
scoreboard objectives add s20c dummy

scoreboard objectives add s21 dummy
scoreboard objectives add s22 dummy
scoreboard objectives add s23 dummy
scoreboard objectives add s24 dummy
scoreboard objectives add s25 dummy
scoreboard objectives add s26 dummy
scoreboard objectives add s27 dummy
scoreboard objectives add s28 dummy
scoreboard objectives add s29 dummy
scoreboard objectives add s30 dummy
scoreboard objectives add s31 dummy
scoreboard objectives add s32 dummy
scoreboard objectives add s33 dummy
scoreboard objectives add s34 dummy
scoreboard objectives add s35 dummy
scoreboard objectives add s36 dummy
scoreboard objectives add s37 dummy
scoreboard objectives add s38 dummy
scoreboard objectives add s39 dummy
scoreboard objectives add s40 dummy
scoreboard objectives add s41 dummy
scoreboard objectives add s42 dummy
scoreboard objectives add s43 dummy
scoreboard objectives add s44 dummy
scoreboard objectives add s45 dummy
scoreboard objectives add s46 dummy
scoreboard objectives add s47 dummy
scoreboard objectives add s48 dummy
scoreboard objectives add s49 dummy
scoreboard objectives add s50 dummy
scoreboard objectives add s51 dummy
scoreboard objectives add s52 dummy
scoreboard objectives add s53 dummy
scoreboard objectives add s54 dummy
scoreboard objectives add s55 dummy
scoreboard objectives add s56 dummy
scoreboard objectives add s57 dummy
scoreboard objectives add s58 dummy
scoreboard objectives add s59 dummy
scoreboard objectives add s60 dummy
scoreboard objectives add s61 dummy
scoreboard objectives add s62 dummy
scoreboard objectives add s63 dummy
scoreboard objectives add s64 dummy
scoreboard objectives add s65 dummy
scoreboard objectives add s66 dummy
scoreboard objectives add s67 dummy
scoreboard objectives add s68 dummy
scoreboard objectives add s69 dummy
scoreboard objectives add s70 dummy
scoreboard objectives add s71 dummy
scoreboard objectives add s72 dummy
scoreboard objectives add s73 dummy
scoreboard objectives add s74 dummy
scoreboard objectives add s75 dummy
scoreboard objectives add s76 dummy
scoreboard objectives add s77 dummy
scoreboard objectives add s78 dummy
scoreboard objectives add s79 dummy
scoreboard objectives add s80 dummy
scoreboard objectives add s81 dummy
scoreboard objectives add s82 dummy
scoreboard objectives add s83 dummy
scoreboard objectives add s84 dummy
scoreboard objectives add s85 dummy
scoreboard objectives add s86 dummy
scoreboard objectives add s87 dummy
scoreboard objectives add s88 dummy
scoreboard objectives add s89 dummy
scoreboard objectives add s90 dummy
scoreboard objectives add s91 dummy
scoreboard objectives add s92 dummy
scoreboard objectives add s93 dummy
scoreboard objectives add s94 dummy
scoreboard objectives add s95 dummy
scoreboard objectives add s96 dummy
scoreboard objectives add s97 dummy
scoreboard objectives add s98 dummy
scoreboard objectives add s99 dummy
scoreboard objectives add s100 dummy

say hi