
execute as @e[type=armor_stand,tag=skill] at @s run function tutorial:area
execute as @e[type=armor_stand,tag=skill] at @s run function tutorial:armor

execute as @a at @s run function tutorial:player
#say hi
execute as @e[scores={fly=1..}] at @s run function tutorial:fly

execute as @e[tag=mob] at @s run function tutorial:mob
#execute if predicate tutorial:ran3 run say hi
#execute as @e[type=#tutorial:mob] run say hi
#scoreboard players remove @e[type=!player,type=!item,type=!armor_stand,type=!experience_orb] s10 1
