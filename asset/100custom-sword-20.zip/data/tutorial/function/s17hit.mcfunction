effect give @s slowness 1 0 true
effect give @s strength 1 0 true