scoreboard players set @s s14a -5
scoreboard players add @s s14 2
execute if entity @s[scores={s14=20}] run playsound block.beacon.activate voice @a ~ ~ ~ 2 1
execute if entity @s[scores={s14=40}] run playsound block.beacon.activate voice @a ~ ~ ~ 2 1.4
execute if entity @s[scores={s14=60}] run playsound block.beacon.activate voice @a ~ ~ ~ 2 1.9
execute if entity @s[scores={s14=80}] run playsound minecraft:item.totem.use voice @a ~ ~ ~ 1 1.2
execute if entity @s[scores={s14=80..}] run effect give @s slowness 1 1 true

execute if entity @s[scores={s14=20}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.1 5
execute if entity @s[scores={s14=40}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.1 10
execute if entity @s[scores={s14=60}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.1 30
execute if entity @s[scores={s14=80}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.4 300
execute if entity @s[scores={s14=80..}] run effect give @s slowness 1 1 true

#say h