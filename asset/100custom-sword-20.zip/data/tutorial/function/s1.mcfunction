playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1

execute anchored eyes run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s1","ice"]}

execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s1] ^ ^-1.25 ^1 ~ ~
scoreboard players set @s s1 10
scoreboard players remove @s mana 60
