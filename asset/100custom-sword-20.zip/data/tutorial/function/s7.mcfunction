playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
playsound item.trident.thunder voice @a ~ ~ ~ 2 2


execute anchored eyes run summon armor_stand ^ ^-1.25 ^4 {Invisible:1b,DisabledSlots:4144959,Duration:20,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s7a"]}
execute anchored eyes run summon armor_stand ^ ^-1.25 ^8 {Invisible:1b,DisabledSlots:4144959,Duration:20,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s7b"]}
execute anchored eyes run summon armor_stand ^ ^-1.25 ^12 {Invisible:1b,DisabledSlots:4144959,Duration:20,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s7c"]}

scoreboard players set @s s7 40
scoreboard players remove @s mana 100
