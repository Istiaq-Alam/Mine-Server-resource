particle minecraft:item{item:{id:ice}} ~ ~0.5 ~ 0.2 0.2 0.2 0.1 50 force @a
playsound entity.ender_eye.death voice @a ~ ~ ~ 2 1.5
kill @e[tag=water,distance=..5]