scoreboard players remove @s s13 1
tp @s ^ ^ ^0.4

execute at @s run effect give @e[distance=..2.1,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob13,type=!armor_stand,type=!item] slowness 3 0
execute at @s as @e[distance=..2.1,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob13,type=!armor_stand,type=!item] at @s run damage @s 13 minecraft:mob_projectile by @e[scores={s13=1..},limit=1,sort=nearest]

execute at @s run effect give @a[distance=..2.1,scores={s13=..13}] slowness 3 0
execute at @s as @a[distance=..2.1,scores={s13=..13},tag=!ff] at @s run damage @s 13 minecraft:mob_projectile by @e[scores={s13=1..},limit=1,sort=nearest]
execute if entity @e[distance=..2.1,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob13,type=!armor_stand,type=!item] run kill @s


particle item{item:{id:honey_block}} ~ ~ ~ 0.1 0.1 0.1 0 5 force

execute unless block ~ ~ ~ #air run kill @s
execute at @s[scores={s13=1..}] run function tutorial:s13b