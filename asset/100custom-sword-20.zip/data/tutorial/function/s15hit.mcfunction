scoreboard players set @s s15 10
execute positioned ^ ^1.25 ^1 run function tutorial:swww2
particle item{item:{id:redstone}} ^ ^1.25 ^2 0.7 0 0.7 0.3 120 force @a
playsound entity.phantom.bite voice @a ~ ~ ~ 2 0.7
playsound entity.phantom.bite voice @a ~ ~ ~ 2 0.7
playsound entity.phantom.bite voice @a ~ ~ ~ 2 0.7
playsound entity.phantom.bite voice @a ~ ~ ~ 2 0.7
playsound entity.phantom.bite voice @a ~ ~ ~ 2 0.7
playsound entity.phantom.bite voice @a ~ ~ ~ 2 0.7

effect give @s saturation 1 5 true


scoreboard players set @s Pskill_cd 40