setblock ~ ~ ~1 anvil
summon minecraft:armor_stand ~-0.6 ~0.3 ~1.4 {Invisible:true,NoBasePlate:true,NoGravity:true,ShowArms:true,Pose:{RightArm:[94f,91f,0f]}}
item replace entity @e[type=armor_stand] weapon.mainhand with iron_sword