playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1

execute anchored eyes run summon armor_stand ^ ^-1.15 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s11","wood"]}
scoreboard players set @s s11 200
scoreboard players remove @s mana 60
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s11] ^ ^-1.25 ^1 ~ ~
