execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
fill ~1 ~ ~1 ~-1 ~ ~-1 air replace fire
execute at @s[scores={skilltime=2..}] run tp @s ^ ^ ^0.35
particle falling_water ~ ~1 ~ 0.7 0.1 0.7 0.01 30 force @a
#particle sweep_attack ~ ~1 ~ 1.2 0 1.2 0.01 5 force @a
#function tutorial:s10p1
#execute positioned ~ ~1 ~ run function tutorial:att
playsound entity.player.splash voice @a ~ ~ ~ 0.5 2
playsound entity.player.splash voice @a ~ ~ ~ 0.5 1.8
playsound entity.player.splash voice @a ~ ~ ~ 0.5 1.6
#fire

execute at @s run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob10] slowness 4 0
execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob10] at @s run damage @s 6 minecraft:mob_projectile by @e[scores={s10=1..},limit=1,sort=nearest]

execute at @s run effect give @a[distance=..3,scores={s10a=1..}] speed 1 0

execute unless block ~ ~0.5 ~ air run kill @s
execute at @s run effect give @a[distance=..3,scores={s10=..1}] slowness 4 0
execute at @s as @a[distance=..3,scores={s10=..1},tag=!ff] at @s run damage @s 7 minecraft:mob_projectile by @e[scores={s10=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=..2}] rotated as @p[scores={s10=1..},limit=1,sort=nearest,distance=..5] run tp @s ~ ~ ~ ~ ~
kill @s[scores={skilltime=40..}]


execute if entity @e[type=armor_stand,tag=fire,distance=..3] run function tutorial:nofire