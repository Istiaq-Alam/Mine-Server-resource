playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1

execute unless entity @s[scores={s14=80..}] anchored eyes run summon armor_stand ^ ^-1.5 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:15,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s14","s14c"]}
execute unless entity @s[scores={s14=80..}] anchored eyes run summon armor_stand ^2 ^-1.5 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:15,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s14","s14a"]}

execute if entity @s[scores={s14=80..}] anchored eyes run summon armor_stand ^ ^-1.5 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s14","s14a"]}
execute if entity @s[scores={s14=80..}] anchored eyes run summon armor_stand ^ ^-1.5 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s14","s14b"]}
execute if entity @s[scores={s14=80..}] anchored eyes run summon armor_stand ^ ^-1.5 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s14","s14c"]}
execute if entity @s[scores={s14=80..}] anchored eyes run summon armor_stand ^ ^-1.5 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s14","s14d"]}
execute if entity @s[scores={s14=80..}] run tag @e[distance=..5,tag=s14] add s14s


execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s14a] ^1 ^-1.5 ^1.5 ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s14c] ^-1 ^-1.5 ^1.5 ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s14b] ^-6 ^-1.5 ^0.5 ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s14d] ^6 ^-1.5 ^0.5 ~ ~
scoreboard players remove @s[scores={s14=80..}] mana 140
scoreboard players set @s s14 10
scoreboard players remove @s mana 80
