execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute at @s[scores={skilltime=2..}] run tp @s ^ ^ ^1
execute at @s[scores={skilltime=2}] run summon armor_stand ^ ^ ^ {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s9a","fire"]}
execute at @s[scores={skilltime=5}] run summon armor_stand ^ ^ ^ {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s9a","fire"]}
execute at @s[scores={skilltime=8}] run summon armor_stand ^ ^ ^ {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s9a","fire"]}

execute at @s[scores={skilltime=2}] run particle flame ~ ~ ~ 1 0.1 1 0.2 50 force @a
execute at @s[scores={skilltime=5}] run particle flame ~ ~ ~ 1 0.1 1 0.2 50 force @a
execute at @s[scores={skilltime=8}] run particle flame ~ ~ ~ 1 0.1 1 0.2 50 force @a
#fill ~1 ~ ~1 ~-1 ~ ~-1 air replace fire

#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
#function tutorial:s9p1
#execute positioned ~ ~1 ~ run function tutorial:att

#fire



execute unless block ~ ~0.5 ~ air run kill @s
execute at @s rotated as @p[scores={s9=1..},limit=1,sort=nearest,distance=..2] run tp @s ~ ~ ~ ~ ~



kill @s[scores={skilltime=10..}]
