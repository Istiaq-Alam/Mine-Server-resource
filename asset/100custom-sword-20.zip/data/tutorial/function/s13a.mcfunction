execute at @s[scores={s13=1..}] positioned ^ ^1.25 ^0.5 run function tutorial:s13b
kill @s[scores={skilltime=4..}]
