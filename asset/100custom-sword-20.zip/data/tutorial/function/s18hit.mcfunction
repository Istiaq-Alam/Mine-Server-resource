
scoreboard players set @s s9 61
summon armor_stand ^-3.7 ^1 ^2 {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s18a"]}
summon armor_stand ^3.7 ^1 ^2 {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s18a"]}
summon armor_stand ^ ^1 ^3 {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s18a"]}
particle flame ^ ^1 ^3 3 0.1 3 0.2 500 force @a
scoreboard players set @s s18 100

playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5
playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5
playsound entity.drowned.shoot voice @a ~ ~ ~ 1 0.5
scoreboard players set @s Pskill_cd 240