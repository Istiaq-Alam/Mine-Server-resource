scoreboard players add @s skilltime 1

execute if entity @s[tag=s11a] run function tutorial:s11b
