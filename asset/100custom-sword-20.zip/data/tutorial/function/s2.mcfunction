playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
#function tutorial:s2ring
execute anchored eyes run summon armor_stand ~ ~ ~ {Invisible:1b,DisabledSlots:4144959,Duration:4,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s2"]}

#execute anchored eyes run summon armor_stand ^ ^-1.25 ^1.5 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s2"]}
particle dust{color:[1.0,0.97,0.14],scale:1} ~ ~10 ~ 0.25 10 0.25 0 500 force @a
particle end_rod ~ ~10 ~ 0.25 10 0.25 0.05 50 force @a
particle end_rod ~ ~0.25 ~ 5 0.1 5 0.05 50 force @a
execute as @e[distance=..8,nbt={active_effects:[{id:"minecraft:wither"}]},type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob2] at @s run damage @s 25 minecraft:mob_projectile by @e[scores={s2=1..},limit=1,sort=nearest]
execute as @a[distance=..8,nbt={active_effects:[{id:"minecraft:wither"}]},scores={s2=..0},tag=!ff,tag=!mob2] at @s run damage @s 25 minecraft:mob_projectile by @e[scores={s2=1..},limit=1,sort=nearest]

effect give @e[distance=..8,nbt=!{active_effects:[{id:"minecraft:wither"}]},tag=!mob2] regeneration 5 1
effect clear @e[distance=..8] wither
scoreboard players set @s s2 10
scoreboard players remove @s mana 60
