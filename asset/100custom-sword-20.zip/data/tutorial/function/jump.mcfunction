execute if entity @s[scores={jump1=1}] run data merge entity @s {Motion:[-1.3d,0.4d,0d]}
execute if entity @s[scores={jump1=2}] run data merge entity @s {Motion:[1.3d,0.4d,0d]}
execute if entity @s[scores={jump1=3}] run data merge entity @s {Motion:[0d,0.4d,1.3d]}
execute if entity @s[scores={jump1=4}] run data merge entity @s {Motion:[0d,0.4d,-1.3d]}
playsound entity.horse.jump voice @a ~ ~ ~ 2 1
