
execute if entity @s[tag=!mobstart] run function tutorial:mobstart
scoreboard players set @s 2 4

effect give @s speed 10000 1 true 
effect give @s resistance 10000 2 true 
effect give @s strength 10000 1 true 
execute if entity @s[nbt={HurtTime:8s}] run scoreboard players add @s tp 40
execute as @s store success score @s target on target if entity @s

execute if predicate tutorial:ran5 run scoreboard players add @s[scores={tp=..200}] tp 1
scoreboard players add @s[scores={tp=200..}] tp 1
execute unless entity @p[distance=..35] run scoreboard players set @s[scores={tp=..200}] tp 201


execute if entity @s[scores={tp=203}] at @p run tp ^ ^ ^-5
execute if entity @s[scores={tp=205}] run function tutorial:tp
execute if entity @s[scores={tp=215}] run function tutorial:tp
execute if entity @s[scores={tp=225}] run function tutorial:tp
execute if entity @s[scores={tp=225..}] run scoreboard players set @s tp 1

particle smoke ~ ~1.5 ~ 0.5 1 0.5 0.01 2 force @a


particle minecraft:dust{color:[0.0,0.0,0.0],scale:2} ~ ~ ~ 0.2 0 0.2 0 3 force @a
scoreboard players remove @s jump 1
execute if entity @e[type=#impact_projectiles,distance=..10,tag=!pp1] run scoreboard players set @s[scores={jump=..-50}] jump 100

tag @e[type=#impact_projectiles,distance=..10] add pp1
execute at @s[scores={jump=99}] run function tutorial:jump
execute at @s[scores={jump=96..98}] run particle cloud ~ ~ ~ 0.1 0.1 0.1 0.1 3 force @a
scoreboard players add @s jump1 1
scoreboard players set @s[scores={jump1=4..}] jump1 1

execute unless entity @s[scores={target=1}] run scoreboard players set @s mobskill 100
scoreboard players reset @s target
#scoreboard players remove @s mobskill 1
execute if entity @p[distance=1..2] run scoreboard players remove @s mobskill 1
execute if entity @p[distance=2..3] run scoreboard players remove @s mobskill 3
execute if entity @p[distance=3..4] run scoreboard players remove @s mobskill 2
execute if entity @p[distance=4..5] run scoreboard players remove @s mobskill 2
execute if entity @p[distance=5..6] run scoreboard players remove @s mobskill 4
execute if entity @p[distance=6..7] run scoreboard players remove @s mobskill 4
execute if entity @p[distance=7..8] run scoreboard players remove @s mobskill 3
execute if entity @p[distance=8..9] run scoreboard players remove @s mobskill 5
execute if entity @p[distance=9..10] run scoreboard players remove @s mobskill 2
execute if entity @p[distance=10..11] run scoreboard players remove @s mobskill 1
execute if entity @p[distance=11..12] run scoreboard players remove @s mobskill 3
execute if entity @p[distance=12..13] run scoreboard players remove @s mobskill 3
execute if entity @p[distance=13..14] run scoreboard players remove @s mobskill 5
execute if entity @p[distance=14..15] run scoreboard players remove @s mobskill 4
execute if entity @p[distance=15..16] run scoreboard players remove @s mobskill 5
execute if entity @p[distance=16..17] run scoreboard players remove @s mobskill 7
execute if entity @p[distance=17..18] run scoreboard players remove @s mobskill 4
execute if entity @p[distance=18..19] run scoreboard players remove @s mobskill 3
execute if entity @p[distance=19..20] run scoreboard players remove @s mobskill 6
#execute if entity @p[distance=2..3] run say hi
#execute if entity @s[scores={mobskill=..10}] run particle angry_villager ~ ~1 ~ 0.1 0.5 0.1 0.1 5 force @a
tag @s[scores={mobskill=..0}] add reset

execute if entity @s[tag=reset,tag=mob1] run function tutorial:s1
execute if entity @s[tag=mob2,tag=reset] run function tutorial:s2
execute if entity @s[tag=reset,tag=mob3] run function tutorial:s3
execute if entity @s[tag=reset,tag=mob4] run function tutorial:s4
execute if entity @s[tag=reset,tag=mob5] run function tutorial:s5
execute if entity @s[tag=reset,tag=mob6] run function tutorial:s6
execute if entity @s[tag=reset,tag=mob7] run function tutorial:s7
execute if entity @s[tag=reset,tag=mob8] run function tutorial:s8
execute if entity @s[tag=reset,tag=mob9] run function tutorial:s9
execute if entity @s[tag=reset,tag=mob10] run function tutorial:s10
execute if entity @s[tag=reset,tag=mob11] run function tutorial:s11
execute if entity @s[tag=reset,tag=mob12] run function tutorial:s12
execute if entity @s[tag=reset,tag=mob13] run function tutorial:s13
execute if entity @s[tag=reset,tag=mob14] run function tutorial:s14
execute if entity @s[tag=reset,tag=mob15] run function tutorial:s15
execute if entity @s[tag=reset,tag=mob16] run function tutorial:s16
execute if entity @s[tag=reset,tag=mob17] run function tutorial:s17
execute if entity @s[tag=reset,tag=mob18] run function tutorial:s18
execute if entity @s[tag=reset,tag=mob19] run function tutorial:s19
execute if entity @s[tag=reset,tag=mob20] run function tutorial:s20

execute if entity @s[tag=reset] run tag @e[distance=..4,type=armor_stand] add mobskill 
execute if entity @e[type=armor_stand,distance=..10,tag=!mobskill] run scoreboard players set @s[scores={jump=..-50}] jump 100

execute if entity @s[scores={s5=0..}] run function tutorial:s5a
scoreboard players remove @s s5 1

scoreboard players operation @s[tag=reset] mobskill = @s mana
scoreboard players operation @s[tag=reset] mobskill *= @s 2

scoreboard players set @s[tag=reset] mana 0
scoreboard players set @s[tag=reset] mobskill 300



tag @s remove reset