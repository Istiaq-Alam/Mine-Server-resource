execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute at @s[scores={skilltime=2..}] run tp @s ^ ^ ^1.4
#particle item{item:{id:blue_stained_glass_pane}} ~ ~1 ~ 0.7 0 0.7 0.01 20 force @a
particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
particle crit ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a

#execute positioned ~ ~1 ~ run function tutorial:att
playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 2
#fire

execute at @s as @e[distance=..2.5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob12] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s12=1..},limit=1,sort=nearest]

kill @s[scores={skilltime=7..}]

execute unless block ~ ~0.5 ~ air run kill @s
execute at @s as @a[distance=..3,scores={s12=..1},tag=!ff] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s12=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=..2}] rotated as @p[scores={s12=1..},limit=1,sort=nearest,distance=..3] run tp @s ~ ~ ~ ~ ~

