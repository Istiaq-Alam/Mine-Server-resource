scoreboard players set @s s4 10
#execute positioned ^ ^1.25 ^1 run function tutorial:s3hitp
##particle item{item:{id:blue_stained_glass_pane}} ^ ^1.25 ^2 0.7 0 0.7 0.3 120 force @a
playsound entity.ender_dragon.growl voice @a ~ ~ ~ 2 2

effect give @s strength 3 1
#execute positioned ^ ^1.25 ^1 run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] wither 5 0
#execute positioned ^ ^1.25 ^1 run effect give @a[distance=..3,scores={s3=..1}] wither 5 0


scoreboard players set @s Pskill_cd 200