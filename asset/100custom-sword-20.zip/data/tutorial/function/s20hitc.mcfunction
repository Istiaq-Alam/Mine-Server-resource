particle item{item:{id:red_candle}} ~ ~1.5 ~ 0.5 1 0.5 0.2 50 force @a
particle cloud ~ ~ ~ 0.1 0 0.1 0.2 40 force @a

particle item{item:{id:red_candle}} ~ ~ ~ 0.1 0 0.1 0 60 force @a
execute if entity @s[scores={hit=1..}] positioned ^ ^1.5 ^3 run function tutorial:s20hitd
execute at @s[scores={s20c=0}] run playsound block.anvil.place voice @a ~ ~ ~ 2 1.7
effect clear @s[scores={s20c=0}] speed
effect give @s[scores={s20c=0}] slowness 10 2 true
effect give @s[scores={s20c=0}] weakness 10 1 true
effect give @s[scores={s20c=0}] hunger 10 100 true
effect give @s[scores={s20c=0}] nausea 5 1 true


