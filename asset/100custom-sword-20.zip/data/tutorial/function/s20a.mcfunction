execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
#execute at @s[scores={skilltime=2..}] run tp @s ^ ^ ^1.6
#particle item{item:{id:blue_stained_glass_pane}} ~ ~1 ~ 0.7 0 0.7 0.01 20 force @a
#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
#function tutorial:s20p1
#execute positioned ~ ~1 ~ run function tutorial:att

particle sweep_attack ~ ~1.5 ~ 1.5 1.5 1.5 3 10 force @a

particle item{item:{id:red_candle}} ~ ~1.5 ~ 1.5 1.5 1.5 0.1 10 force @a

playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 2
playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1.8
playsound entity.drowned.shoot voice @a ~ ~ ~ 0.5 1.6
#fire

#execute at @s run effect give @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob20] slowness 3 1
execute at @s as @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob20] at @s run damage @s 7 minecraft:mob_projectile by @e[scores={s20=1..},limit=1,sort=nearest]


execute unless block ~ ~0.5 ~ air run kill @s
#execute at @s run effect give @a[distance=..4,scores={s20=..1}] slowness 3 1
execute at @s as @a[distance=..4,scores={s20=..1},tag=!ff] at @s run damage @s 7 minecraft:mob_projectile by @e[scores={s20=1..},limit=1,sort=nearest]
#execute at @s[scores={skilltime=..2}] rotated as @p[scores={s20=1..},limit=1,sort=nearest,distance=..4] run tp @s ~ ~ ~ ~ ~

execute if entity @e[type=armor_stand,tag=skill,tag=!s20,distance=..4] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=armor_stand,tag=skill,tag=!s20,distance=..4] run particle flash ~ ~ ~ 0 0 0 0 1 force @a

execute if entity @e[type=#impact_projectiles,distance=..4] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=#impact_projectiles,distance=..4] run particle flash ~ ~ ~ 0 0 0 0 1 force @a

kill @e[type=#impact_projectiles,distance=..4]
kill @e[type=armor_stand,tag=skill,tag=!s20,distance=..4]




kill @s[scores={skilltime=10..}]

execute if entity @e[type=armor_stand,tag=water,distance=..4] run function tutorial:nowater