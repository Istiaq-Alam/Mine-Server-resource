scoreboard players set @s s6 10
playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 2 0.7

#particle item{item:{id:stone}} ~ ~1 ~ 3 0.1 3 0.1 500 force @a
particle explosion ^ ^1 ^1 0 0 0 0 1 force @a

scoreboard players add @a[distance=..6,scores={s6=..-20},limit=1,sort=nearest] fly 10
scoreboard players add @e[distance=..6,type=!player,type=!item,type=!armor_stand,type=!experience_orb,limit=1,sort=nearest] fly 10


scoreboard players set @s Pskill_cd 100