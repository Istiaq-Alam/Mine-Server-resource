scoreboard players set .manaspeed manaspeed 1
playsound entity.arrow.hit_player voice @a ~ ~ ~ 1 1
tellraw @s [{"text":"<Mana regeneration rate has been set to 5 mana per second>","color":"dark_green"}]
scoreboard players set @a mana 1