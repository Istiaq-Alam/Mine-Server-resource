playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1

#execute anchored eyes run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s19","ice"]}
#execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s19] ^ ^-1.25 ^1 ~ ~
#

effect give @s absorption 1 3 true
effect give @s absorption 10 1 true
playsound block.beacon.power_select voice @a ~ ~ ~ 2 1.7
playsound block.beacon.power_select voice @a ~ ~ ~ 2 1.7
playsound block.beacon.power_select voice @a ~ ~ ~ 2 1.7
playsound block.beacon.power_select voice @a ~ ~ ~ 2 1.7
playsound block.beacon.power_select voice @a ~ ~ ~ 2 1.7
playsound block.beacon.power_select voice @a ~ ~ ~ 2 1.7
particle item{item:{id:gold_block}} ~ ~1 ~ 0.1 0.6 0.1 0.2 200 force @a
particle end_rod ~ ~1 ~ 0.1 0.6 0.1 0.2 200 force @a

scoreboard players set @s s19 10
scoreboard players remove @s mana 100
