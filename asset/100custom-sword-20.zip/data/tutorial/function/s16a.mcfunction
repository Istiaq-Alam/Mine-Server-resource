
#particle item{item:{id:blue_stained_glass_pane}} ~ ~1 ~ 0.7 0 0.7 0.01 20 force @a
#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
function tutorial:s16p
#execute positioned ~ ~1 ~ run function tutorial:att
#playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 2
#fire

#execute at @s run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob16] slowness 3 1
execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob16] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s16=1..},limit=1,sort=nearest]


#execute unless block ~ ~0.5 ~ air run kill @s
#execute at @s run effect give @a[distance=..4,scores={s1=..1}] slowness 3 1
execute at @s as @a[distance=..3,scores={s16=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s16=1..},limit=1,sort=nearest]
#execute at @s[scores={skilltime=..2}] rotated as @p[scores={s1=1..},limit=1,sort=nearest,distance=..3] run tp @s ~ ~ ~ ~ ~

kill @s[scores={skilltime=3..}]


#execute if entity @e[type=armor_stand,tag=water,distance=..3] run function tutorial:nowater