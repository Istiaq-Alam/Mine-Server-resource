function tutorial:revoke

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:101}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:101}]] run function tutorial:s1
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:102}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:102}]] run function tutorial:s2
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:103}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:103}]] run function tutorial:s3
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:104}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=100..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:104}]] run function tutorial:s4
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..100}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:105}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:105}]] run function tutorial:s5
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:106}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=100..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:106}]] run function tutorial:s6
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..100}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:107}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=100..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:107}]] run function tutorial:s7
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:108}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:108}]] run function tutorial:s8
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:109}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:109}]] run function tutorial:s9
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:110}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:110}]] run function tutorial:s10

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:111}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:111}]] run function tutorial:s11

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:112}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:112}]] run function tutorial:s12

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..80}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:113}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=80..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:113}]] run function tutorial:s13

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..80}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:114}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=80..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:114}]] run function tutorial:s14

execute if score @s skill_cd matches ..1 if items entity @s weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:115}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:115}]] run function tutorial:s15

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..40}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:116}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=40..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:116}]] run function tutorial:s16


execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..80}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:117}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=80..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:117}]] run function tutorial:s17
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..120}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:118}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=120..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:118}]] run function tutorial:s18
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:119}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:119}]] run function tutorial:s19

execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=..60}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:120}]] run function tutorial:nomana
execute if score @s skill_cd matches ..1 if items entity @s[scores={mana=60..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:120}]] run function tutorial:s20


execute if score @s skill_cd matches ..1 run scoreboard players set @s skill_cd 10