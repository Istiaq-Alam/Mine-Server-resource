scoreboard players set .FF FF 2
playsound entity.arrow.hit_player voice @a ~ ~ ~ 1 1
tellraw @s [{"text":"<Friendly Fire has been off>","color":"red"}]