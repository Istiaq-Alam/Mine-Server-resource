playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1

execute anchored eyes run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s12"]}
scoreboard players set @s s12 10
scoreboard players remove @s[scores={mana=..100}] mana 60

scoreboard players remove @s[scores={mana=100..}] mana 30
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s12] ^ ^-1.25 ^1 ~ ~
