playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
playsound block.beacon.activate voice @a ~ ~ ~ 2 0.8
function tutorial:s3ring
scoreboard players set @s s3 10
execute anchored eyes run summon armor_stand ~ ~ ~ {Invisible:1b,DisabledSlots:4144959,Duration:4,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s3"]}

#execute anchored eyes run summon armor_stand ^ ^-1.25 ^1.5 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s3"]}
particle dust{color:[0.54,0.11,0.57],scale:1} ~ ~10 ~ 0.25 10 0.25 0 500 force @a
particle dragon_breath ~ ~10 ~ 0.25 10 0.25 0.05 50 force @a 
particle dragon_breath ~ ~0.25 ~ 5 0.1 5 0.05 100 force @a
execute as @e[distance=..8,nbt={active_effects:[{id:"minecraft:regeneration"}]},type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob3] at @s run damage @s 25 minecraft:mob_projectile by @e[scores={s3=1..},limit=1,sort=nearest]
execute as @a[distance=..8,nbt={active_effects:[{id:"minecraft:regeneration"}]},scores={s3=..0},tag=!ff,tag=!mob3] at @s run damage @s 25 minecraft:mob_projectile by @e[scores={s3=1..},limit=1,sort=nearest]

effect give @e[distance=..8,nbt=!{active_effects:[{id:"minecraft:regeneration"}]},type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob3] wither 5 1
effect give @a[distance=..8,scores={s3=..1},nbt=!{active_effects:[{id:"minecraft:regeneration"}]},tag=!mob3] wither 5 1

#effect clear @e[distance=..8] regeneration
scoreboard players set @s s3 10
scoreboard players remove @s mana 60
