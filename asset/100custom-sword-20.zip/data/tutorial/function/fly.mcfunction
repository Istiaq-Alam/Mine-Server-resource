effect give @s[scores={fly=10}] levitation 1 30 true
effect clear @s[scores={fly=6}] levitation
#execute at @s[scores={fly=10}] run summon wind_charge ~ ~ ~ {Motion:[0d,-10d],Silent:1b}
scoreboard players remove @s fly 1