particle item{item:{id:red_candle}} ~ ~1.5 ~ 0.7 1 0.7 0.2 100 force @a
scoreboard players set @s s20c 10
playsound item.totem.use voice @a ~ ~ ~ 2 2
effect clear @s slowness 
effect give @s speed 1 100 true
effect give @s strength 1 200 true
scoreboard players set @s Pskill_cd 200