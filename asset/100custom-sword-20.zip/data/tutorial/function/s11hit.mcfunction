scoreboard players set @s s11 10
execute positioned ^ ^1.25 ^1 run function tutorial:s11hitp
#particle item{item:{id:blue_stained_glass_pane}} ^ ^1.25 ^2 0.7 0 0.7 0.3 120 force @a
playsound block.grass.break voice @a ~ ~ ~ 2 0.5



execute positioned ^ ^1.25 ^1 run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] weakness 3 1
execute positioned ^ ^1.25 ^1 run effect give @a[distance=..3,scores={s11=..1}] weakness 3 1


scoreboard players set @s Pskill_cd 60