playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
effect give @s slowness 1 3 true

effect give @s speed 9 1 true
effect give @s strength 9 1 true
effect give @s instant_damage 1 0 true

effect give @s wither 9 0 true

playsound minecraft:entity.ender_dragon.growl voice @a ~ ~ ~ 2 2
particle item{item:{id:redstone}} ~ ~1 ~ 0.3 0.7 0.3 0.5 300 force @a
particle item{item:{id:redstone}} ~ ~1 ~ 0.3 0.7 0.3 0.1 500 force @a

scoreboard players set @s s15 10
#scoreboard players remove @s mana 60
