scoreboard players reset @s sneak
scoreboard players reset @s sneak1