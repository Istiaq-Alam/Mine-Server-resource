scoreboard players set @s s1 10
execute positioned ^ ^1.25 ^1 run function tutorial:swww2
particle item{item:{id:blue_stained_glass_pane}} ^ ^1.25 ^2 0.7 0 0.7 0.3 120 force @a
playsound entity.ender_eye.death voice @a ~ ~ ~ 2 1


execute positioned ^ ^1.25 ^1 run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] slowness 2 2
execute positioned ^ ^1.25 ^1 run effect give @a[distance=..3,scores={s1=..1}] slowness 2 2


scoreboard players set @s Pskill_cd 100