playsound entity.drowned.shoot voice @a ~ ~ ~ 2 2
playsound minecraft:entity.illusioner.prepare_mirror voice @a ~ ~ ~ 1.5 2
playsound minecraft:entity.illusioner.prepare_mirror voice @a ~ ~ ~ 1.5 2
playsound minecraft:entity.illusioner.prepare_mirror voice @a ~ ~ ~ 1.5 2

playsound minecraft:entity.illusioner.prepare_mirror voice @a ~ ~ ~ 1.5 2
playsound minecraft:entity.illusioner.prepare_blindness voice @a ~ ~ ~ 1.5 2

execute anchored eyes run summon armor_stand ^ ^-0.7 ^2 {Invisible:1b,DisabledSlots:4144959,Duration:3,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s8"]}



execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s8] ^ ^-0.7 ^2 ~ ~


scoreboard players set @s s8 15
scoreboard players remove @s mana 60
