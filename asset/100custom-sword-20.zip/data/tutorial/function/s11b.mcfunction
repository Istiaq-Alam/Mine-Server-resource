
execute at @s[scores={skilltime=1}] run tp @s ^ ^-0.7 ^
execute at @s[scores={skilltime=1}] run particle item{item:{id:pink_dye}} ~ ~4 ~ 0.1 0.1 0.1 0.1 250 force @a

execute at @s[scores={skilltime=1}] run playsound block.grass.break voice @a ~ ~ ~ 1 2
execute at @s[scores={skilltime=3}] run playsound block.grass.break voice @a ~ ~ ~ 1 2
execute at @s[scores={skilltime=5}] run playsound block.grass.break voice @a ~ ~ ~ 1 2

execute at @s[scores={skilltime=1}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=1}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=1}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=1}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=1}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=5}] run item replace entity @s armor.head with spore_blossom
particle spore_blossom_air ~ ~4 ~ 0.7 0 0.7 0.01 10 force @a

#item replace entity @s armor.head with spore_blossom

#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
#function tutorial:s1p1
##execute positioned ~ ~1 ~ run function tutorial:att
#playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 2
#playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 1.8
#playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 1.6
#fire

#playsound block.moss.place voice @a ~ ~ ~ 2 0.5


attribute @s[scores={skilltime=1}] minecraft:scale base set 4

execute at @s[scores={skilltime=5}] run particle item{item:{id:pink_dye}} ~ ~4 ~ 0.5 0.2 0.5 0.3 400 force @a
execute at @s[scores={skilltime=5}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=5}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=5}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=5}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=5}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5

execute at @s[scores={skilltime=5}] run effect give @e[distance=..5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11] slowness 2 0
execute at @s[scores={skilltime=5}] run effect give @e[distance=..5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11] weakness 3 0
execute at @s[scores={skilltime=5}] run effect give @a[distance=..5,scores={s11=..1}] weakness 3 0
execute at @s[scores={skilltime=5}] run effect give @a[distance=..5,scores={s11=..1}] slowness 3 0

execute at @s[scores={skilltime=5}] as @a[distance=..5,scores={s11=..1},tag=!ff] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s11=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=5}] as @e[distance=..5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s11=1..},limit=1,sort=nearest]


execute at @s[scores={skilltime=45}] run particle item{item:{id:pink_dye}} ~ ~4 ~ 0.5 0.2 0.5 0.3 400 force @a
execute at @s[scores={skilltime=45}] run effect give @a[distance=..5,scores={s11=..1}] weakness 3 0
execute at @s[scores={skilltime=45}] as @e[distance=..5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s11=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=45}] as @a[distance=..5,scores={s11=..1},tag=!ff] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s11=1..},limit=1,sort=nearest]

execute at @s[scores={skilltime=45}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=45}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=45}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=45}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5


execute at @s[scores={skilltime=85}] run particle item{item:{id:pink_dye}} ~ ~4 ~ 0.5 0.2 0.5 0.3 400 force @a
execute at @s[scores={skilltime=85}] run effect give @a[distance=..5,scores={s11=..1}] weakness 3 0

execute at @s[scores={skilltime=85}] as @e[distance=..5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s11=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=85}] as @a[distance=..5,scores={s11=..1},tag=!ff] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s11=1..},limit=1,sort=nearest]

execute at @s[scores={skilltime=85}] run effect give @e[distance=..5,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11] weakness 3 0


execute at @s[scores={skilltime=85}] run playsound block.grass.break voice @a ~ ~ ~ 1 1
execute at @s[scores={skilltime=85}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=85}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=85}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=85}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5
execute at @s[scores={skilltime=85}] run playsound entity.ender_eye.death voice @a ~ ~ ~ 1 0.5

kill @s[scores={skilltime=85..}]


execute at @s[scores={skilltime=2..}] run tp @s ~ ~ ~ ~15 ~



