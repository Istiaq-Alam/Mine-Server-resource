effect give @s slowness 1 1 true
#playsound block.anvil.place voice @a ~ ~ ~ 1 1.5

#tellraw @s [{"text":"you don't have enough mana!","color":"red"}]
#