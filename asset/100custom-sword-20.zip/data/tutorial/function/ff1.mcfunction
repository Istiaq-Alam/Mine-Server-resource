scoreboard players set .FF FF 1
playsound entity.arrow.hit_player voice @a ~ ~ ~ 1 1
tellraw @s [{"text":"<Friendly Fire has been on>","color":"dark_green"}]