execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute at @s[scores={skilltime=2..}] run tp @s ^ ^ ^1.6
#particle item{item:{id:blue_stained_glass_pane}} ~ ~1 ~ 0.7 0 0.7 0.01 20 force @a
#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
function tutorial:s1p1
#execute positioned ~ ~1 ~ run function tutorial:att
playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 2
playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 1.8
playsound minecraft:block.amethyst_block.step voice @a ~ ~ ~ 0.5 1.6
#fire

execute at @s run effect give @e[tag=!mob1,distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] slowness 3 1
execute at @s as @e[tag=!mob1,distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s1=1..},limit=1,sort=nearest]


execute unless block ~ ~0.5 ~ air run kill @s
execute at @s run effect give @a[distance=..3,scores={s1=..1}] slowness 3 1
execute at @s as @a[distance=..3,scores={s1=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s1=1..},limit=1,sort=nearest]
#execute at @s[scores={skilltime=..2}] rotated as @p[scores={s1=1..},limit=1,sort=nearest,distance=..3] run tp @s ~ ~ ~ ~ ~

kill @s[scores={skilltime=20..}]

execute if entity @e[type=armor_stand,tag=water,distance=..3] run function tutorial:nowater