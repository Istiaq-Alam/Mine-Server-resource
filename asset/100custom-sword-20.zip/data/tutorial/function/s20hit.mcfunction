scoreboard players set @s s20b -5
scoreboard players add @s s20a 1
execute if entity @s[scores={s20a=20}] run playsound block.fire.extinguish voice @a ~ ~ ~ 2 0.5
execute if entity @s[scores={s20a=20}] run particle cloud ~ ~1 ~ 0.2 0.5 0.2 0.1 5
execute if entity @s[scores={s20a=20..80}] run particle item{item:{id:red_candle}} ~ ~1.5 ~ 0.7 1 0.7 0 1 force @a
execute if entity @s[scores={s20a=20..80}] run effect give @s slowness 2 5 true

execute if entity @s[scores={s20a=60}] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute if entity @s[scores={s20a=60}] run particle flash ~ ~1.5 ~ 0 0 0 0.1 1
execute if entity @s[scores={s20a=80}] run playsound block.beacon.deactivate voice @a ~ ~ ~ 2 1
execute if entity @s[scores={s20a=80}] run effect clear @s slowness
execute if entity @s[scores={s20a=80}] run scoreboard players set @s s20a -20
#execute if entity @s[scores={s20a=40}] run playsound block.beacon.activate voice @a ~ ~ ~ 2 1.4
#execute if entity @s[scores={s20a=60}] run playsound block.beacon.activate voice @a ~ ~ ~ 2 1.9
#execute if entity @s[scores={s20a=80}] run playsound minecraft:item.totem.use voice @a ~ ~ ~ 1 1.2
#execute if entity @s[scores={s20a=80..}] run effect give @s slowness 1 1 true

#execute if entity @s[scores={s20a=20}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.1 5
#execute if entity @s[scores={s20a=40}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.1 10
#execute if entity @s[scores={s20a=60}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.1 30
#execute if entity @s[scores={s20a=80}] run particle end_rod ~ ~1 ~ 0.2 0.5 0.2 0.4 300
#execute if entity @s[scores={s20a=80..}] run effect give @s slowness 1 1 true

#say h