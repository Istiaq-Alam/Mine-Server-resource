#scoreboard players add @s skilltime 1

execute if entity @s[tag=s1] run function tutorial:s1a

execute if entity @s[tag=s2] run function tutorial:s2ring
execute if entity @s[tag=s3] run function tutorial:s3ring


execute if entity @s[tag=s7a] run function tutorial:s7a
execute if entity @s[tag=s7b] run function tutorial:s7b
execute if entity @s[tag=s7c] run function tutorial:s7c

execute if entity @s[tag=s8] run function tutorial:s8a

execute if entity @s[tag=s9] run function tutorial:s9a
execute if entity @s[tag=s9a] run function tutorial:s9b

execute if entity @s[tag=s10] run function tutorial:s10a
execute if entity @s[tag=s11] run function tutorial:s11a
execute if entity @s[tag=s12] run function tutorial:s12a
execute if entity @s[tag=s13] run function tutorial:s13a
execute if entity @s[tag=s14] run function tutorial:s14a
execute if entity @s[tag=s15] run function tutorial:s15a
execute if entity @s[tag=s16] run function tutorial:s16a
execute if entity @s[tag=s16a] run function tutorial:s16b
execute if entity @s[tag=s17] run function tutorial:s17a
execute if entity @s[tag=s18] run function tutorial:s18a
execute if entity @s[tag=s18a] run function tutorial:s18b

execute if entity @s[tag=s19] run function tutorial:s19a
execute if entity @s[tag=s20] run function tutorial:s20a
