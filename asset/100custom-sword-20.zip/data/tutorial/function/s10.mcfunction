playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
execute anchored eyes run summon armor_stand ^2 ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s10","water","s10a"]}
execute anchored eyes run summon armor_stand ^-2 ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s10","water","s10b"]}

execute anchored eyes run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:40,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s10","water","s10c"]}
scoreboard players set @s s10 60
scoreboard players set @s s10a 60
scoreboard players remove @s mana 60
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s10a] ^2 ^-1.25 ^1 ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s10b] ^-2 ^-1.25 ^1 ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s10c] ^ ^-1.25 ^1 ~ ~
