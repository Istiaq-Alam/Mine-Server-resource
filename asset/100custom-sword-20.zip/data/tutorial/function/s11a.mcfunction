execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
execute at @s[scores={skilltime=2..}] run tp @s ^ ^ ^1.1
particle item{item:{id:moss_block}} ~ ~ ~ 0.1 0.1 0.1 0.01 20 force @a
particle item{item:{id:pink_dye}} ~ ~ ~ 0.1 0.1 0.1 0.1 10 force @a

#particle sweep_attack ~ ~ ~ 0.7 0 0.7 0.01 5 force @a
#function tutorial:s11p1
#execute positioned ~ ~ ~ run function tutorial:att
playsound block.moss.place voice @a ~ ~ ~ 0.5 0.5
playsound block.moss.place voice @a ~ ~ ~ 0.5 0.5
playsound block.moss.place voice @a ~ ~ ~ 0.5 0.5
playsound block.moss.place voice @a ~ ~ ~ 0.5 0.5

#fire

execute at @s[scores={skilltime=2..}] if entity @e[limit=1,distance=..2.5,type=!armor_stand,type=!item,type=!experience_orb,tag=!mob11,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11,type=!armor_stand] run summon minecraft:armor_stand ~ ~-3 ~ {NoGravity:true,Invisible:true,DisabledSlots:4144959,Pose:{Head:[180f,0f,0f]},ArmorItems:[{},{},{},{id:"minecraft:spore_blossom",Count:1}],Tags:["skill","wood","s11a"]}
execute at @s if entity @p[distance=..2.5,scores={s11=..1}] run summon minecraft:armor_stand ~ ~-3 ~ {NoGravity:true,Invisible:true,DisabledSlots:4144959,Pose:{Head:[180f,0f,0f]},ArmorItems:[{},{},{},{id:"minecraft:spore_blosso1m",Count:1}],Tags:["skill","wood","s11a"]}
execute at @s[scores={skilltime=2..}] at @e[limit=1,distance=..2.5,type=!armor_stand,type=!item,type=!experience_orb,tag=!mob11,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob11,type=!armor_stand] run kill @s
execute at @s if entity @p[distance=..2.5,scores={s11=..1}] run kill @s


execute at @s[scores={skilltime=..2}] rotated as @p[scores={s11=1..},limit=1,sort=nearest,distance=..2.5] run tp @s ~ ~ ~ ~ ~

execute at @s[scores={skilltime=20}] run summon minecraft:armor_stand ~ ~-3 ~ {NoGravity:true,Invisible:true,DisabledSlots:4144959,Pose:{Head:[180f,0f,0f]},ArmorItems:[{},{},{},{id:"minecraft:spore_blossom1",Count:1}],Tags:["skill","wood","s11a"]}

execute unless block ^ ^ ^1 air run summon minecraft:armor_stand ~ ~-3 ~ {NoGravity:true,Invisible:true,DisabledSlots:4144959,Pose:{Head:[180f,0f,0f]},ArmorItems:[{},{},{},{id:"minecraft:spore_bloss1om",Count:1}],Tags:["skill","wood","s11a"]}
execute unless block ^ ^ ^1 air run kill @s


kill @s[scores={skilltime=20..}]

execute if entity @e[type=armor_stand,tag=water,distance=..2.5] run function tutorial:nowater