playsound block.shroomlight.place voice @a ~ ~ ~ 2 0.5
playsound block.shroomlight.place voice @a ~ ~ ~ 2 0.6
playsound block.shroomlight.place voice @a ~ ~ ~ 2 0.7
playsound block.shroomlight.place voice @a ~ ~ ~ 2 0.8
playsound block.shroomlight.place voice @a ~ ~ ~ 2 0.9

execute anchored eyes run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:4,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s13","ice"]}
scoreboard players set @e[type=armor_stand,tag=s13] s13 30
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s13] ^ ^ ^ ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s13] ^ ^-1.25 ^1 ~ ~

execute if entity @s[scores={sneak=1..}] run scoreboard players add @e[type=armor_stand,tag=s13,limit=1,distance=..3] s13 50
effect give @s[scores={sneak=1..}] slowness 3 3 true
execute if entity @s[scores={sneak=1..}] run playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 1 2
execute if entity @s[scores={sneak=1..}] run tp @s ^ ^ ^ ~ ~-8
scoreboard players set @s s13 50
scoreboard players remove @s mana 80
