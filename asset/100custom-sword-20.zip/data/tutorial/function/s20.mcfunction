playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1

execute anchored eyes run summon armor_stand ^ ^-1.25 ^3 {Invisible:1b,DisabledSlots:4144959,Duration:10,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s20","blood"]}
effect give @s slowness 1 1 true
#execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s20] ^ ^-1.25 ^1 ~ ~
scoreboard players set @s s20 20
scoreboard players remove @s mana 60
