execute if block ~ ~0.5 ~ tall_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy

execute if block ~ ~0.5 ~ short_grass run fill ~ ~0.5 ~ ~ ~0.5 ~ air destroy
#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
execute at @s[scores={skilltime=2..}] run function tutorial:s8p
#execute positioned ~ ~1 ~ run function tutorial:att

#fire

execute at @s run effect give @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob8] slowness 3 1 true
execute at @s as @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob8] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s8=1..},limit=1,sort=nearest]


execute at @s as @a[distance=..4,scores={s8=..1},tag=!ff] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s8=1..},limit=1,sort=nearest]
execute at @s rotated as @p[scores={s8=1..},limit=1,sort=nearest,distance=..4.5] run tp @s ~ ~ ~ ~ ~

execute if entity @e[type=armor_stand,distance=..4,tag=!s8] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=armor_stand,distance=..4,tag=!s8] run particle flash ~ ~ ~ 0 0 0 0 1 force @a
kill @e[type=armor_stand,distance=..4,tag=!s8]

effect clear @e[distance=..4,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob8]
effect clear @a[distance=..4,scores={s8=..1}]


execute if entity @e[type=armor_stand,tag=skill,tag=!s8,distance=..4] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=armor_stand,tag=skill,tag=!s8,distance=..4] run particle flash ~ ~ ~ 0 0 0 0 1 force @a

execute if entity @e[type=#impact_projectiles,distance=..4] run playsound block.anvil.place voice @a ~ ~ ~ 2 2
execute at @e[type=#impact_projectiles,distance=..4] run particle flash ~ ~ ~ 0 0 0 0 1 force @a
execute if entity @e[type=#impact_projectiles,distance=..4] run scoreboard players add @p[distance=..5,scores={s8=1..}] mana 30

kill @e[type=#impact_projectiles,distance=..4]
kill @e[type=armor_stand,tag=skill,tag=!s8,distance=..4]

kill @s[scores={skilltime=3..}]
