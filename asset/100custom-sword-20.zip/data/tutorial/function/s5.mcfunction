
scoreboard players set @s s5 10
scoreboard players remove @s mana 60
