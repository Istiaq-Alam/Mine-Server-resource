playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 2 0.7
playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 2 0.7
playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 2 0.7
playsound entity.lightning_bolt.impact voice @a ~ ~ ~ 2 0.7
scoreboard players set @s s6 10

particle item{item:{id:stone}} ~ ~1 ~ 3 0.1 3 0.1 500 force @a
particle explosion ~ ~ ~ 3 0.1 3 0 100 force @a
scoreboard players add @a[distance=..6,scores={s6=..0},sort=nearest] fly 10
scoreboard players add @e[distance=..6,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob6,sort=nearest] fly 10
execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob6] at @s run damage @s 22.5 minecraft:mob_projectile by @e[scores={s6=1..},limit=1,sort=nearest]
execute at @s as @a[distance=..3,scores={s6=..0},tag=!ff] run damage @s 22.5 minecraft:mob_projectile by @e[scores={s6=1..},limit=1,sort=nearest]

execute at @s as @e[distance=3.1..6,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob6] at @s run damage @s 15 minecraft:mob_projectile by @e[scores={s6=1..},limit=1,sort=nearest]
execute at @s as @a[distance=3.1..6,scores={s6=..0},tag=!ff] run damage @s 15 minecraft:mob_projectile by @e[scores={s6=1..},limit=1,sort=nearest]

#/particle dust{color:[0.16,0.57,0.11],scale:1} ~ ~1 ~ 0 0 0 0 1
effect give @s slowness 2 2 true


scoreboard players remove @s mana 100
