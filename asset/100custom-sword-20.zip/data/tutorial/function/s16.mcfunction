playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7
playsound minecraft:entity.player.hurt_sweet_berry_bush voice @a ~ ~ ~ 2 0.7

execute anchored eyes at @s[scores={s16a=1..4}] run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:2,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s16"]}
execute anchored eyes at @s[scores={s16a=5..}] run summon armor_stand ^ ^-1.25 ^1 {Invisible:1b,DisabledSlots:4144959,Duration:2,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s16a"]}

execute anchored eyes at @s[scores={s16a=5..}] run playsound entity.phantom.bite voice @a ~ ~ ~ 1 1
scoreboard players reset @s[scores={s16a=5..}] s16a
scoreboard players add @s s16a 1

execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s16] ^ ^-0.5 ^3 ~ ~
execute anchored eyes rotated as @s run tp @e[type=armor_stand,tag=s16a] ^ ^-0.5 ^3 ~ ~


execute if entity @s[scores={s16a=5}] run playsound minecraft:block.fire.extinguish voice @a ~ ~ ~ 1 1.4
execute if entity @s[scores={s16a=5}] run particle item{item:{id:redstone}} ~ ~1 ~ 0.3 0 0.3 0.2 50 force @a
execute if entity @s[scores={s16a=5}] run scoreboard players add @s s16a 1

scoreboard players set @s s16 10
scoreboard players remove @s mana 40
