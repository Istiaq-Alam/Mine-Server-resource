effect give @s[scores={s5=9}] speed 1 30
effect clear @s[scores={s5=1}] speed
playsound entity.drowned.shoot voice @a ~ ~ ~ 2 2
execute if entity @s[scores={s5=9}] run playsound block.fire.extinguish voice @a ~ ~ ~ 2 2
execute if entity @s[scores={s5=9}] run playsound block.fire.extinguish voice @a ~ ~ ~ 2 2
execute if entity @s[scores={s5=9}] run playsound block.fire.extinguish voice @a ~ ~ ~ 2 2
execute if entity @s[scores={s5=9}] run playsound block.fire.extinguish voice @a ~ ~ ~ 2 2
execute if entity @s[scores={s5=9}] run particle cloud ~ ~1 ~ 0.5 1 0.5 0.1 100 force @a
execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob5] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s5=1..},limit=1,sort=nearest]
execute at @s as @a[distance=..3,scores={s5=..-0},tag=!ff] at @s run damage @s 10 minecraft:mob_projectile by @e[scores={s5=1..},limit=1,sort=nearest]

execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob5] at @s run particle sweep_attack ~ ~1 ~ 0.3 1 0.3 1 3
execute at @s as @a[distance=..3,scores={s5=..0}] at @s run particle sweep_attack ~ ~1 ~ 0.3 1 0.3 1 3



particle cloud ~ ~0.3 ~ 0 0 0 0.05 10 force @a