#particle item{item:{id:blue_stained_glass_pane}} ^ ^1.25 ^2 0.7 0 0.7 0.3 120 force @a
playsound minecraft:block.beacon.activate voice @a ~ ~ ~ 2 1.7
playsound minecraft:block.beacon.activate voice @a ~ ~ ~ 2 1.7
playsound minecraft:block.beacon.activate voice @a ~ ~ ~ 2 1.7
playsound minecraft:block.beacon.activate voice @a ~ ~ ~ 2 1.7
playsound minecraft:block.beacon.activate voice @a ~ ~ ~ 2 1.7
particle item{item:{id:gold_block}} ~ ~1 ~ 0.8 0.6 0.8 0.01 100 force @a
scoreboard players add @s[scores={mana=..170}] mana 30
scoreboard players set @s[scores={mana=170..}] mana 200

#execute positioned ^ ^1.25 ^1 run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] slowness 2 2
#execute positioned ^ ^1.25 ^1 run effect give @a[distance=..3,scores={s1=..1}] slowness 2 2


scoreboard players set @s Pskill_cd 60