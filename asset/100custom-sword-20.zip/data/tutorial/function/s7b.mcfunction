

particle dust{color:[1.0,0.85,0.14],scale:1} ~ ~0.1 ~ 1 0.1 1 0 20
particle electric_spark ~ ~0.1 ~ 1 0.1 1 0 20

execute if block ^ ^-0.3 ^ air run tp @s ~ ~-0.1 ~

execute at @s[scores={skilltime=22..}] run summon lightning_bolt ~0.3 ~ ~0.3
execute at @s[scores={skilltime=22..}] run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] slowness 3 1 true
execute at @s[scores={skilltime=22..}] as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob7] at @s run damage @s 30 minecraft:mob_projectile by @e[scores={s7=1..},limit=1,sort=nearest]
execute at @s[scores={skilltime=22..}] as @a[distance=..3,scores={s7=..1},tag=!ff] at @s run damage @s 30 minecraft:mob_projectile by @e[scores={s7=1..},limit=1,sort=nearest]
kill @s[scores={skilltime=22..}]



