
scoreboard players set @s s9 61

summon armor_stand ^ ^1 ^3 {Invisible:1b,DisabledSlots:4144959,Duration:60,PersistenceRequired:1,CustomName:"\"Skill\"",NoAI:1,Invisible:1b,NoBasePlate:1b,NoGravity:1b,Tags:["skill","s9a"]}
particle flame ^ ^1 ^3 1 0.1 1 0.2 50 force @a

scoreboard players set @s Pskill_cd 100