
particle flame ~ ~ ~ 1 0.1 1 0.01 10 force @a
particle lava ~ ~ ~ 1 0.1 1 0.01 1 force @a

execute at @s[scores={skilltime=2}] run playsound entity.blaze.shoot voice @a ~ ~ ~ 1 1
execute at @s[scores={skilltime=5}] run playsound block.fire.ambient voice @a ~ ~ ~ 1 1
execute at @s[scores={skilltime=9}] run playsound block.fire.ambient voice @a ~ ~ ~ 1 1
execute if block ~ ~-0.1 ~ air run tp @s ~ ~-0.1 ~
#particle sweep_attack ~ ~1 ~ 0.7 0 0.7 0.01 5 force @a
#execute positioned ~ ~1 ~ run function tutorial:att
#fire

execute at @s as @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb,tag=!mob9] at @s run damage @s 2.5 minecraft:mob_projectile by @e[scores={s9=1..},limit=1,sort=nearest]


execute at @s as @a[distance=..3,scores={s9=..1},tag=!ff] at @s run damage @s 2.5 minecraft:mob_projectile by @e[scores={s9=1..},limit=1,sort=nearest]



kill @s[scores={skilltime=60..}]
