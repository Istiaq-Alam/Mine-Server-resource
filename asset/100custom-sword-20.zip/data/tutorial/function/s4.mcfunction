playsound entity.drowned.shoot voice @a ~ ~ ~ 2 1
playsound block.anvil.place voice @a ~ ~ ~ 2 0.7
playsound block.anvil.place voice @a ~ ~ ~ 2 0.7
playsound block.anvil.place voice @a ~ ~ ~ 2 0.7
playsound block.anvil.place voice @a ~ ~ ~ 2 0.7

particle item{item:{id:turtle_scute}} ~ ~1 ~ 0.5 1 0.5 0 100 force @a
particle dust{color:[0.16,0.57,0.11],scale:1} ~ ~1 ~ 0.5 1 0.5 0 100 force @a

#/particle dust{color:[0.16,0.57,0.11],scale:1} ~ ~1 ~ 0 0 0 0 1
effect give @s slowness 5 0 true
effect give @s resistance 5 0 true


scoreboard players set @s s4 10
scoreboard players remove @s mana 100
