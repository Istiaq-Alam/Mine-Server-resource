function tutorial:cd


execute if predicate tutorial:ran5 run scoreboard players add @s mob 1

execute if entity @s[scores={mob=1800..}] if predicate tutorial:ran3 run tag @e[type=#tutorial:mob,limit=1,distance=..50] add mob
scoreboard players reset @s[scores={mob=1800..}] mob

execute if score @s s1 matches -30.. run scoreboard players remove @s s1 1
execute if score @s s2 matches -30.. run scoreboard players remove @s s2 1
execute if score @s s3 matches -30.. run scoreboard players remove @s s3 1
execute if score @s s4 matches -30.. run scoreboard players remove @s s4 1
execute if score @s s5 matches -30.. run scoreboard players remove @s s5 1
execute if score @s s6 matches -30.. run scoreboard players remove @s s6 1
execute if score @s s7 matches -30.. run scoreboard players remove @s s7 1
execute if score @s s8 matches -30.. run scoreboard players remove @s s8 1
execute if score @s s9 matches -30.. run scoreboard players remove @s s9 1
execute if score @s s10 matches -30.. run scoreboard players remove @s s10 1
execute if score @s s11 matches -30.. run scoreboard players remove @s s11 1
execute if score @s s12 matches -30.. run scoreboard players remove @s s12 1
execute if score @s s13 matches -30.. run scoreboard players remove @s s13 1
execute if score @s s14 matches -30.. run scoreboard players remove @s s14 1
execute if score @s s15 matches -30.. run scoreboard players remove @s s15 1
execute if score @s s16 matches -30.. run scoreboard players remove @s s16 1
execute if score @s s17 matches -30.. run scoreboard players remove @s s17 1
execute if score @s s18 matches -30.. run scoreboard players remove @s s18 1
execute if score @s s19 matches -30.. run scoreboard players remove @s s19 1
execute if score @s s20 matches -30.. run scoreboard players remove @s s20 1
execute if score @s s21 matches -30.. run scoreboard players remove @s s21 1
execute if score @s s22 matches -30.. run scoreboard players remove @s s22 1
execute if score @s s23 matches -30.. run scoreboard players remove @s s23 1
execute if score @s s24 matches -30.. run scoreboard players remove @s s24 1
execute if score @s s25 matches -30.. run scoreboard players remove @s s25 1
execute if score @s s26 matches -30.. run scoreboard players remove @s s26 1
execute if score @s s27 matches -30.. run scoreboard players remove @s s27 1
execute if score @s s28 matches -30.. run scoreboard players remove @s s28 1
execute if score @s s29 matches -30.. run scoreboard players remove @s s29 1
execute if score @s s30 matches -30.. run scoreboard players remove @s s30 1
execute if score @s s31 matches -30.. run scoreboard players remove @s s31 1
execute if score @s s32 matches -30.. run scoreboard players remove @s s32 1
execute if score @s s33 matches -30.. run scoreboard players remove @s s33 1
execute if score @s s34 matches -30.. run scoreboard players remove @s s34 1
execute if score @s s35 matches -30.. run scoreboard players remove @s s35 1
execute if score @s s36 matches -30.. run scoreboard players remove @s s36 1
execute if score @s s37 matches -30.. run scoreboard players remove @s s37 1
execute if score @s s38 matches -30.. run scoreboard players remove @s s38 1
execute if score @s s39 matches -30.. run scoreboard players remove @s s39 1
execute if score @s s40 matches -30.. run scoreboard players remove @s s40 1
execute if score @s s41 matches -30.. run scoreboard players remove @s s41 1
execute if score @s s42 matches -30.. run scoreboard players remove @s s42 1
execute if score @s s43 matches -30.. run scoreboard players remove @s s43 1
execute if score @s s44 matches -30.. run scoreboard players remove @s s44 1
execute if score @s s45 matches -30.. run scoreboard players remove @s s45 1
execute if score @s s46 matches -30.. run scoreboard players remove @s s46 1
execute if score @s s47 matches -30.. run scoreboard players remove @s s47 1
execute if score @s s48 matches -30.. run scoreboard players remove @s s48 1
execute if score @s s49 matches -30.. run scoreboard players remove @s s49 1
execute if score @s s50 matches -30.. run scoreboard players remove @s s50 1
execute if score @s s51 matches -30.. run scoreboard players remove @s s51 1
execute if score @s s52 matches -30.. run scoreboard players remove @s s52 1
execute if score @s s53 matches -30.. run scoreboard players remove @s s53 1
execute if score @s s54 matches -30.. run scoreboard players remove @s s54 1
execute if score @s s55 matches -30.. run scoreboard players remove @s s55 1
execute if score @s s56 matches -30.. run scoreboard players remove @s s56 1
execute if score @s s57 matches -30.. run scoreboard players remove @s s57 1
execute if score @s s58 matches -30.. run scoreboard players remove @s s58 1
execute if score @s s59 matches -30.. run scoreboard players remove @s s59 1
execute if score @s s60 matches -30.. run scoreboard players remove @s s60 1
execute if score @s s61 matches -30.. run scoreboard players remove @s s61 1
execute if score @s s62 matches -30.. run scoreboard players remove @s s62 1
execute if score @s s63 matches -30.. run scoreboard players remove @s s63 1
execute if score @s s64 matches -30.. run scoreboard players remove @s s64 1
execute if score @s s65 matches -30.. run scoreboard players remove @s s65 1
execute if score @s s66 matches -30.. run scoreboard players remove @s s66 1
execute if score @s s67 matches -30.. run scoreboard players remove @s s67 1
execute if score @s s68 matches -30.. run scoreboard players remove @s s68 1
execute if score @s s69 matches -30.. run scoreboard players remove @s s69 1
execute if score @s s70 matches -30.. run scoreboard players remove @s s70 1
execute if score @s s71 matches -30.. run scoreboard players remove @s s71 1
execute if score @s s72 matches -30.. run scoreboard players remove @s s72 1
execute if score @s s73 matches -30.. run scoreboard players remove @s s73 1
execute if score @s s74 matches -30.. run scoreboard players remove @s s74 1
execute if score @s s75 matches -30.. run scoreboard players remove @s s75 1
execute if score @s s76 matches -30.. run scoreboard players remove @s s76 1
execute if score @s s77 matches -30.. run scoreboard players remove @s s77 1
execute if score @s s78 matches -30.. run scoreboard players remove @s s78 1
execute if score @s s79 matches -30.. run scoreboard players remove @s s79 1
execute if score @s s80 matches -30.. run scoreboard players remove @s s80 1
execute if score @s s81 matches -30.. run scoreboard players remove @s s81 1
execute if score @s s82 matches -30.. run scoreboard players remove @s s82 1
execute if score @s s83 matches -30.. run scoreboard players remove @s s83 1
execute if score @s s84 matches -30.. run scoreboard players remove @s s84 1
execute if score @s s85 matches -30.. run scoreboard players remove @s s85 1
execute if score @s s86 matches -30.. run scoreboard players remove @s s86 1
execute if score @s s87 matches -30.. run scoreboard players remove @s s87 1
execute if score @s s88 matches -30.. run scoreboard players remove @s s88 1
execute if score @s s89 matches -30.. run scoreboard players remove @s s89 1
execute if score @s s90 matches -30.. run scoreboard players remove @s s90 1
execute if score @s s91 matches -30.. run scoreboard players remove @s s91 1
execute if score @s s92 matches -30.. run scoreboard players remove @s s92 1
execute if score @s s93 matches -30.. run scoreboard players remove @s s93 1
execute if score @s s94 matches -30.. run scoreboard players remove @s s94 1
execute if score @s s95 matches -30.. run scoreboard players remove @s s95 1
execute if score @s s96 matches -30.. run scoreboard players remove @s s96 1
execute if score @s s97 matches -30.. run scoreboard players remove @s s97 1
execute if score @s s98 matches -30.. run scoreboard players remove @s s98 1
execute if score @s s99 matches -30.. run scoreboard players remove @s s99 1
execute if score @s s100 matches -30.. run scoreboard players remove @s s100 1
scoreboard players remove @s skill_cd 1
scoreboard players remove @s Pskill_cd 1

execute if score .FF FF matches 1 run tag @s remove ff
execute if score .FF FF matches 2 run tag @s add ff

execute unless score @s mana matches 201.. if score .manaspeed manaspeed matches 1 run scoreboard players add @s mana1 2
execute unless score @s mana matches 201.. if score .manaspeed manaspeed matches 2 run scoreboard players add @s mana1 5
execute unless score @s mana matches 201.. if score .manaspeed manaspeed matches 3 run scoreboard players add @s mana1 10

scoreboard players add @s[scores={mana1=10..}] mana 1
scoreboard players reset @s[scores={mana1=10..}] mana1

function tutorial:cd


execute if score @s Pskill_cd matches -30.. if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=0..200}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"score":{"name":"@s","objective":"mana","color":"green"}},{"text":" || ","bold":true,"color":"yellow"},{"text":"CD: ","bold":true,"color":"green"},{"score":{"name":"@s","objective":"cd","color":"green"},"color":"yellow"},{"text":"s","bold":true,"color":"yellow"}]
execute if score @s Pskill_cd matches -30.. if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=201}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"text":"200","bold":true,"color":"gold"},{"text":" || ","bold":true,"color":"yellow"},{"text":"CD: ","bold":true,"color":"green"},{"score":{"name":"@s","objective":"cd","color":"green"},"color":"yellow"},{"text":"s","bold":true,"color":"yellow"}]
execute if score @s Pskill_cd matches -30.. if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=201..300}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"text":"200","bold":true,"color":"gold"},{"text":" || ","bold":true,"color":"yellow"},{"text":"CD: ","bold":true,"color":"green"},{"score":{"name":"@s","objective":"cd","color":"green"},"color":"yellow"},{"text":"s","bold":true,"color":"yellow"}]

execute if score @s Pskill_cd matches -30.. run title @s[scores={mana=0..200}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"score":{"name":"@s","objective":"mana","color":"green"}},{"text":" || ","bold":true,"color":"yellow"},{"text":"CD: ","bold":true,"color":"green"},{"score":{"name":"@s","objective":"cd","color":"green"},"color":"yellow"},{"text":"s","bold":true,"color":"yellow"}]
execute if score @s Pskill_cd matches -30.. run title @s[scores={mana=..0}] actionbar [{"text":"Mana:","bold":true,"color":"red"},{"score":{"name":"@s","objective":"mana","color":"green"}},{"text":" || ","bold":true,"color":"yellow"},{"text":"CD: ","bold":true,"color":"green"},{"score":{"name":"@s","objective":"cd","color":"green"},"color":"yellow"},{"text":"s","bold":true,"color":"yellow"}]

execute if score @s Pskill_cd matches ..0 if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=0..200}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"score":{"name":"@s","objective":"mana","color":"green"}}]

#execute if score @s Pskill_cd matches ..0 if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=0..200}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"score":{"name":"@s","objective":"mana","color":"green"}},{"text":" || ","bold":true,"color":"yellow"},{"text":"CD: ","bold":true,"color":"green"},{"score":{"name":"@s","objective":"cd","color":"green"},"color":"yellow"},{"text":"s","bold":true,"color":"yellow"}]
execute if score @s Pskill_cd matches ..0 if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=201}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"text":"200","bold":true,"color":"gold"}]
execute if score @s Pskill_cd matches ..0 if entity @p[nbt={SelectedItem:{id:"minecraft:iron_sword"}}] run title @s[scores={mana=201..300}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"text":"200","bold":true,"color":"gold"}]

execute if score @s Pskill_cd matches ..0 run title @s[scores={mana=0..200}] actionbar [{"text":"Mana:","bold":true,"color":"gold"},{"score":{"name":"@s","objective":"mana","color":"green"}}]
execute if score @s Pskill_cd matches ..0 run title @s[scores={mana=..0}] actionbar [{"text":"Mana:","bold":true,"color":"red"},{"score":{"name":"@s","objective":"mana","color":"red"}}]




execute if items entity @s weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:117}]] run function tutorial:s17hit


#execute as @e[distance=..8,nbt={active_effects:[{id:"minecraft:regeneration"}]},tag=!ff] at @s run damage @s 15
execute if score @s Pskill_cd matches ..0 if items entity @s[nbt={active_effects:[{id:"minecraft:slowness"}]}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:104}]] run function tutorial:s4hit

execute if entity @s[scores={s5=0..}] run function tutorial:s5a

#execute if entity @s[scores={s20=0..}] run function tutorial:s5a


execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:101}]] run function tutorial:s1hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:102}]] run function tutorial:s2hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:103}]] run function tutorial:s3hit
#execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:104}]] run function tutorial:s4hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:105}]] run scoreboard players add @s s5hit 1
execute if entity @s[scores={s5hit=3..}] run playsound entity.breeze.wind_burst voice @a ~ ~ ~ 1 1.5
execute if entity @s[scores={s5hit=3..}] run particle cloud ^ ^1 ^ 0.3 1 0.3 0.1 30
effect give @s[scores={s5hit=3..}] strength 1 2
scoreboard players reset @s[scores={s5hit=3..}] s5hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:105}]] run function tutorial:s5hit

scoreboard players remove @e[scores={s10a=1..},type=!player,type=!item,type=!armor_stand,type=!experience_orb] s10a 1

execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:106}]] run function tutorial:s6hit
execute if score @s Pskill_cd matches ..0 if items entity @s weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:107}]] if entity @e[type=lightning_bolt,distance=..3.3] run function tutorial:s7hit


execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:108}]] run function tutorial:s8hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:109}]] run function tutorial:s9hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:110}]] run function tutorial:s10hit

execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:111}]] run function tutorial:s11hit

execute if items entity @s[scores={sneak1=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:114}]] run function tutorial:s14hit

scoreboard players add @s s14a 1
scoreboard players reset @s[scores={s14a=30..}] s14
scoreboard players reset @s[scores={s14a=30..}] s14a

execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..},nbt={active_effects:[{id:"minecraft:wither"}]}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:115}]] run function tutorial:s15hit

execute if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:116}]] run scoreboard players add @s s16a 1

execute if entity @s[scores={s16a=5}] run playsound minecraft:block.fire.extinguish voice @a ~ ~ ~ 1 1.4
execute if entity @s[scores={s16a=5}] run particle item{item:{id:redstone}} ~ ~1 ~ 0.3 0 0.3 0.2 50 force @a
execute if entity @s[scores={s16a=5}] run scoreboard players add @s s16a 1
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:118}]] run function tutorial:s18hit

execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:119}]] run function tutorial:s19hit

execute if score @s Pskill_cd matches ..0 if items entity @s[scores={sneak1=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:120}]] run function tutorial:s20hit

scoreboard players add @s s20b 1
execute unless entity @s[scores={sneak1=1..}] run scoreboard players add @s s20b 3
execute at @s[scores={s20c=-1..}] run function tutorial:s20hitc
scoreboard players remove @s s20c 1
execute if entity @s[scores={s20a=55..80}] if entity @s[scores={s20b=1..}] run function tutorial:s20hita
scoreboard players reset @s[scores={s20b=1..}] s20a
scoreboard players reset @s[scores={s20b=1..}] s20b

execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:121}]] run function tutorial:s21hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:122}]] run function tutorial:s22hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:123}]] run function tutorial:s23hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:124}]] run function tutorial:s24hit



execute if items entity @s weapon book[enchantments~[{enchantments:"minecraft:unbreaking",levels:99}]] run function tutorial:givebook


execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:125}]] run function tutorial:s25hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:126}]] run function tutorial:s26hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:127}]] run function tutorial:s27hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:128}]] run function tutorial:s28hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:129}]] run function tutorial:s29hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:130}]] run function tutorial:s30hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:131}]] run function tutorial:s31hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:132}]] run function tutorial:s32hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:133}]] run function tutorial:s33hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:134}]] run function tutorial:s34hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:135}]] run function tutorial:s35hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:136}]] run function tutorial:s36hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:137}]] run function tutorial:s37hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:138}]] run function tutorial:s38hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:139}]] run function tutorial:s39hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:140}]] run function tutorial:s40hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:141}]] run function tutorial:s41hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:142}]] run function tutorial:s42hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:143}]] run function tutorial:s43hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:144}]] run function tutorial:s44hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:145}]] run function tutorial:s45hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:146}]] run function tutorial:s46hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:147}]] run function tutorial:s47hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:148}]] run function tutorial:s48hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:149}]] run function tutorial:s49hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:150}]] run function tutorial:s50hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:151}]] run function tutorial:s51hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:152}]] run function tutorial:s52hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:153}]] run function tutorial:s53hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:154}]] run function tutorial:s54hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:155}]] run function tutorial:s55hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:156}]] run function tutorial:s56hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:157}]] run function tutorial:s57hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:158}]] run function tutorial:s58hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:159}]] run function tutorial:s59hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:160}]] run function tutorial:s60hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:161}]] run function tutorial:s61hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:162}]] run function tutorial:s62hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:163}]] run function tutorial:s63hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:164}]] run function tutorial:s64hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:165}]] run function tutorial:s65hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:166}]] run function tutorial:s66hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:167}]] run function tutorial:s67hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:168}]] run function tutorial:s68hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:169}]] run function tutorial:s69hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:170}]] run function tutorial:s70hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:171}]] run function tutorial:s71hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:172}]] run function tutorial:s72hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:173}]] run function tutorial:s73hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:174}]] run function tutorial:s74hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:175}]] run function tutorial:s75hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:176}]] run function tutorial:s76hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:177}]] run function tutorial:s77hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:178}]] run function tutorial:s78hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:179}]] run function tutorial:s79hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:180}]] run function tutorial:s80hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:181}]] run function tutorial:s81hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:182}]] run function tutorial:s82hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:183}]] run function tutorial:s83hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:184}]] run function tutorial:s84hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:185}]] run function tutorial:s85hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:186}]] run function tutorial:s86hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:187}]] run function tutorial:s87hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:188}]] run function tutorial:s88hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:189}]] run function tutorial:s89hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:190}]] run function tutorial:s90hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:191}]] run function tutorial:s91hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:192}]] run function tutorial:s92hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:193}]] run function tutorial:s93hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:194}]] run function tutorial:s94hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:195}]] run function tutorial:s95hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:196}]] run function tutorial:s96hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:197}]] run function tutorial:s97hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:198}]] run function tutorial:s98hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:199}]] run function tutorial:s99hit
execute if score @s Pskill_cd matches ..0 if items entity @s[scores={hit=1..}] weapon iron_sword[enchantments~[{enchantments:"minecraft:unbreaking",levels:200}]] run function tutorial:s100hit


scoreboard players add @s[scores={sneak=1..}] sneak1 1
execute if entity @s[scores={sneak1=10..}] run function tutorial:sneak


execute if entity @s[scores={Pskill_cd=0}] run playsound entity.arrow.hit_player voice @a ~ ~ ~ 1 2
scoreboard players reset @s hit
