scoreboard players set @s s2 10
execute positioned ^ ^1.25 ^1 run function tutorial:s2hitp
#particle item{item:{id:blue_stained_glass_pane}} ^ ^1.25 ^2 0.7 0 0.7 0.3 120 force @a
playsound block.beacon.activate voice @a ~ ~ ~ 2 1.2


execute positioned ^ ^1.25 ^1 run effect give @e[distance=..3,type=!player,type=!item,type=!armor_stand,type=!experience_orb] regeneration 5 0
execute positioned ^ ^1.25 ^1 run effect give @a[distance=..3] regeneration 5 0


scoreboard players set @s Pskill_cd 100